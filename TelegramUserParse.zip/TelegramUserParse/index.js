const { MTProto } = require('telegram-mtproto');
const { Storage } = require('mtproto-storage-fs');
const readline = require('readline');
const fs = require('fs');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
})

var phone = {
    num: '+',
    code: '86355'
};

const config = {
    api_id: '',
    api_hash: ''
}

const app = {
    storage: new Storage('./storage.json')
}

const api = {
    layer: 57,
    initConnection: 0x69796de9,
    api_id: 44444
};

const server = {
    webogram: true,
    dev: false,
};

const telegram = MTProto({ server, api, app });

const askForCode = () => {
    return new Promise((resolve) => {
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        })

        rl.question('Please enter passcode for ' + phone.num + ':\n', (num) => {
            rl.close()
            resolve(num)
        })
    })
}

const login = async (client, phone) => {
    const { phone_code_hash } = await telegram('auth.sendCode', {
        phone_number: phone.num,
        current_number: false,
        api_id: config.api_id,
        api_hash: config.api_hash
    })

    const phone_code = await askForCode()
    console.log(`Your code: ${phone_code}`)

    const { user } = await telegram('auth.signIn', {
        phone_number: phone.num,
        phone_code_hash: phone_code_hash,
        phone_code: phone_code
    })

    console.log('signed as ', user.first_name)
}


const getUserId = async (userLogin) => {
    const { result } = await telegram('users.getFullUser', {
        id: userLogin
    })
    console.log(result);
    return result;
}

const addUserToChat = async (chatId, userInput) => {
    const result = await telegram('messages.addChatUser', {
        chat_id: chatId,
        user_id: userInput,
        fwd_limit: 0
    });
    console.log(`[+] ADD USER[${userInput.id} to CHAT[${chatId}]]`);
}

const getUsers = async () => {
    const result = await telegram('messages.getDialogs');
    console.log(result);
}

const getInputUserByUsername = async (usernameVal) => {
    const result = await telegram('contacts.resolveUsername', {
        username: usernameVal
    })
    const data = {
        _: "inputUser",
        user_id: result.users[0].id,
        access_hash: result.users[0].access_hash
    }
    return data;
}

function main() {
    console.log(`[+] START`);
    var chatId;
    rl.question('Print chat_id: ', (answer) => {
        chatId = answer;
        rl.close();
        var accounts = fs.readFileSync('accounts').toString().split("\n");
        for (i in accounts) {
            getInputUserByUsername(accounts[i].slice(1)).then(val => { addUserToChat(chatId, val); });
        }
    });
}

(async function () {
    if (!(await app.storage.get('signedin'))) {
        console.log('not signed in')
        await login(telegram, phone).catch(console.error)
        console.log('signed in successfully')
        app.storage.set('signedin', true)
    } else {
        console.log('already signed in')
        main();
    }
})()