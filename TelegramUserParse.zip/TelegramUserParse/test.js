const fs = require('fs');

var accounts = fs.readFileSync('accounts').toString().split("\n");
for(i in accounts) {
    console.log(accounts[i].slice(1));
} 